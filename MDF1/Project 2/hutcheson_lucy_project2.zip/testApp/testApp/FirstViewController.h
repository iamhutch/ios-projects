//
//  FirstViewController.h
//  testApp
//
//  Created by Lucy Hutcheson on 10/28/12.
//  Copyright (c) 2012 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController

// Button to load another view
-(IBAction)onMore:(id)sender;

@end
