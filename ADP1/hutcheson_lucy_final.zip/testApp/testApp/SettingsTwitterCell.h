//
//  SettingsTwitterCell.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/27/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsTwitterCell : UITableViewCell
{
    IBOutlet UILabel *selectedAccount;
}

@property (strong, nonatomic)IBOutlet UILabel *selectedAccount;


@end
