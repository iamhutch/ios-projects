//
//  ThirdViewController.m
//  testApp
//
//  Created by Lucy Hutcheson on 5/11/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import "ThirdViewController.h"
#import "SettingsViewController.h"
#import "SettingsTableCell.h"

@interface ThirdViewController ()

@end

@implementation ThirdViewController
@synthesize settingsView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Settings", @"Settings");
        self.tabBarItem.image = [UIImage imageNamed:@"third"];
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated
{
    // Load up default font size
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if(defaults != nil)
    {
        if ([defaults objectForKey:@"defaultFontSize"])
        {
            myFontSize = [defaults objectForKey:@"defaultFontSize"];
            //NSLog(@"User font size: %@", myFontSize);
        } else {
            myFontSize = @"12";
        }
    }
    [settingsTableView reloadRowsAtIndexPaths:[settingsTableView indexPathsForVisibleRows] withRowAnimation:UITableViewRowAnimationNone];

    [super viewWillAppear:animated];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Setup Custom table cell
    static NSString *CellIdentifier = @"Cell";
    SettingsTableCell *fontCell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (fontCell == nil)
    {
        
        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"SettingsTableCell" owner:nil options:nil];
        
        for (UIView *view in views)
        {
            if([view isKindOfClass:[SettingsTableCell class]])
            {
                fontCell = (SettingsTableCell*)view;
                fontCell.selectedSize.text = myFontSize;
            }
        }
    }
    return fontCell;
}


- (void)tableView:(UITableView *)tableView didHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
        // Setup Settings view
        SettingsViewController *mySettingsView = [[SettingsViewController alloc] initWithNibName:@"SettingsViewController" bundle:[NSBundle mainBundle]];
        self.settingsView = mySettingsView;
        
        // Pull up my settings view
        [self.navigationController pushViewController:mySettingsView animated:true];
        
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
