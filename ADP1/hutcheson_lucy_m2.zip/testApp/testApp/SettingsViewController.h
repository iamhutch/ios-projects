//
//  SettingsViewController.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/11/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UIViewController
{
    IBOutlet UISlider *slider;
    IBOutlet UILabel  *fontSize;
    int sliderValue;
    NSUserDefaults *defaults;
    NSString *myFontSize;
}

- (IBAction)sliderChanged:(id)sender;

@end
