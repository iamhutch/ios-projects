//
//  SettingsTableCell.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/14/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsTableCell : UITableViewCell
{
    IBOutlet UILabel *selectedSize;
}

@property (strong, nonatomic)IBOutlet UILabel *selectedSize;

@end
