//
//  ThirdViewController.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/11/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SettingsViewController.h"

@interface ThirdViewController : UIViewController
{
    SettingsViewController *settingsView;
    IBOutlet UITableView *settingsTableView;
    NSString *myFontSize;
}

@property (nonatomic, retain) SettingsViewController *settingsView;

@end
