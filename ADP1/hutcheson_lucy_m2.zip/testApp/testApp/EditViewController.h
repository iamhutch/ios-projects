//
//  EditViewController.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/13/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface EditViewController : UIViewController
{
    NSString *selectedTitle;
    NSString *selectedNotes;
    NSDate *selectedDate;
    IBOutlet UITextField *reminderTitle;
    IBOutlet UITextView *reminderNotes;
    IBOutlet UIDatePicker *reminderDate;
    NSMutableDictionary *editDataDictionary;
}

@property (nonatomic, strong) NSMutableDictionary *editDataDictionary;

-(IBAction)closeKeyboard:(id)sender;

@end
