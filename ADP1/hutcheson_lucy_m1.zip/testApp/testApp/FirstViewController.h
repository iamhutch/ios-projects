//
//  FirstViewController.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/11/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomTableCell.h"
#import "EditViewController.h"
#import "SecondViewController.h"

@class Controller;

@interface FirstViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UITableView *reminderTableView;
    CustomTableCell *customCell;
    Controller *controller;
    NSDictionary *myNewData;
    NSMutableArray *savedData;
    NSDictionary *dataDictionary;
}

@property (nonatomic, retain) NSMutableArray *savedData;
@property (strong, nonatomic) NSDictionary *myNewData;
@property (strong, nonatomic) NSDictionary *dataDictionary;



@end
