//
//  SecondViewController.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/11/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SecondViewController : UIViewController 
{
    IBOutlet UITextField *reminderTitle;
    IBOutlet UITextView *reminderNotes;
    IBOutlet UIDatePicker *reminderDate;
    NSString *myReminder;
    NSString *eventDateFormatted;
    NSDictionary *myReminderData;
}

@property (nonatomic, retain) NSDictionary *myReminderData;

-(IBAction)closeKeyboard:(id)sender;


@end
