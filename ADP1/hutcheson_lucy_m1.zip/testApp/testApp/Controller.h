//
//  Controller.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/14/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Controller : NSObject
{
    
}

-(NSMutableArray*)getData;
@end
