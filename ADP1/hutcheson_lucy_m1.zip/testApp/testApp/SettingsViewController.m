//
//  SettingsViewController.m
//  testApp
//
//  Created by Lucy Hutcheson on 5/11/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import "SettingsViewController.h"
#import "ThirdViewController.h"

@interface SettingsViewController ()

@end

@implementation SettingsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    // Set slider to user's current default font size
    defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"defaultFontSize"])
    {
        NSString *value = [defaults objectForKey:@"defaultFontSize"];
        CGFloat strFloat = (CGFloat)[value floatValue];
        [slider setValue:strFloat animated:YES];
        fontSize.text = value;
    }
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (IBAction)sliderChanged:(id)sender
{
    // Update slider and text field with user selection
    int output = (int)slider.value;
    sliderValue = 2 * floor((output/2)+0.5);
    [slider setValue:sliderValue animated:YES];
    fontSize.text = [NSString stringWithFormat:@"%d",sliderValue];
    //NSLog(@"Font size selected:  %d", sliderValue);
}

-(void)viewWillDisappear:(BOOL)animated
{
    // Save selected font size
    if (defaults != nil)
    {
        // If slider changed, use that value
        if (sliderValue > 0)
        {
            // Setup string and default and sync
            myFontSize = [NSString stringWithFormat:@"%d",sliderValue];
        }
        // Otherwise, if the slider didn't change because they want it the same, use the already selected value.
        else
        {
            myFontSize = fontSize.text;
        }
        [defaults setObject:myFontSize forKey:@"defaultFontSize"];
        [defaults synchronize];
    }

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
