//
//  CustomTableCell.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/11/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EditViewController.h"

@interface CustomTableCell : UITableViewCell <EditViewDelegate>
{
    IBOutlet UIView *topView;
    IBOutlet UIView *bottomView;
    IBOutlet UILabel *titleLabel;
    IBOutlet UILabel *dateLabel;
    IBOutlet UIImage *editButton;
    IBOutlet UIImage *shareButton;
    BOOL *toggleClick;
    id<EditViewDelegate> delegate;
}

@property (strong, nonatomic)IBOutlet UILabel *titleLabel;
@property (strong, nonatomic)IBOutlet UILabel *dateLabel;
@property (strong, nonatomic)IBOutlet UIView *bottomView;
@property (strong, nonatomic)IBOutlet UIView *topView;
@property (strong, nonatomic)IBOutlet UIImage *editButton;
@property (strong, nonatomic)IBOutlet UIImage *shareButton;


- (IBAction)handleSwipe:(UIGestureRecognizer*)recognizer;
- (IBAction)onClick:(id)sender;


@end
