//
//  EditViewController.h
//  testApp
//
//  Created by Lucy Hutcheson on 5/13/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol EditViewDelegate <NSObject>
@end

@interface EditViewController : UIViewController
{
    id<EditViewDelegate> delegate;

}

@property (strong) id<EditViewDelegate> delegate;

@end
