//
//  FirstViewController.m
//  testApp
//
//  Created by Lucy Hutcheson on 5/11/13.
//  Copyright (c) 2013 Lucy Hutcheson. All rights reserved.
//

#import "FirstViewController.h"
#import "CustomTableCell.h"
#import "Controller.h"
#import "Singleton.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

@synthesize savedData, myNewData, dataDictionary;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Home", @"Home");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated
{
    Singleton *instance = [Singleton GetInstance];
    if (instance.data != nil)
    {
        [savedData addObject:instance.data];
        [reminderTableView reloadData];

    }
}

- (void)viewDidLoad
{

    // Pull data
    controller = [[Controller alloc] init];
    if (controller != nil)
    {
        savedData = [controller getData];
        NSLog(@"Saved data loaded");
    }
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (savedData != nil)
    {
        return [savedData count];
    }
    return 0;
}

// Setup custom table cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    CustomTableCell *newCell = [reminderTableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (newCell == nil)
    {
        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"CustomTableCell" owner:nil options:nil];
        for (UIView *view in views)
        {
            if([view isKindOfClass:[CustomTableCell class]])
            {
                newCell = (CustomTableCell*)view;
                // setup dictionary based on data array and setup cell
                dataDictionary = [savedData objectAtIndex:indexPath.row];
                if (dataDictionary != nil)
                {
                    newCell.titleLabel.text = (NSString*)[dataDictionary objectForKey:@"Title"];
                    
                    // Format date field
                    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                    [dateFormatter setDateFormat:@"EEE, MMM d 'at' h:mm a"];
                    newCell.dateLabel.text = [dateFormatter stringFromDate:[dataDictionary objectForKey:@"Date"]];
                }
           }
        }
    }
    return newCell;
}

// Make my table rows taller 
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 63;
}

- (void)tableView:(UITableView *)tableView didHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
   [reminderTableView setAllowsSelection:NO];
    //NSLog(@"row = %d, name = %@", indexPath.row, [reminderTitle objectAtIndex:indexPath.row]);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [UIView animateWithDuration:0.25f animations:^
     {
         if (customCell.topView != nil)
         {
             // move the topview to the left
             customCell.topView.frame = CGRectMake(-150.0f, customCell.topView.frame.origin.y, customCell.topView.frame.size.width, customCell.topView.frame.size.height);
         }
     }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
